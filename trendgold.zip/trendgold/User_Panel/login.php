<?php
include 'header.php';

?>
        <section id="section-17">
            <div class="controls row">
                <div class="col-md-6" id="column-19">
                    <h1 id="heading-22">
                        RAGA<br>
                        COLLECTIONS<br>
                        
                    </h1>
                    <p id="paragraph-23">
                        Raga Collections are our premium collcetions we have, dispute free and single piece per design product.
                    </p><a class="btn btn-primary btn" href="#" id="button-24">View More</a> 
                </div>
                <div class="col-md-6">
                    <img id="image" src="img/6421700d869e3_1679912973.png">
                </div>
                
                <script>
                
                    var imageSources = ["img/6421700d869e3_1679912973.png", "img/Banner_01.png", "img/Banner_02.png"]
                    
                    var index = 0;
                    setInterval (function(){
                      if (index === imageSources.length) {
                        index = 0;
                      }
                      document.getElementById("image").src = imageSources[index];
                      index++;
                    } , 2000);
                
                </script>
            </div>
        </section>
       
        <div class="container">
            <div class="row">
               <div class="col-lg-3"></div>
                <div class="col-lg-5 col-md-10 col-sm-12 col-xs-12 Login" >
                    <h1 id="LoginHeading">Login</h1>  
                    <form action="">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter your email">
                          </div>
                        
                          <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Password</label>
                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter your password">
                          </div>
                        

                          <span class="dont">
                            <a href="Register.php" class="dont">You don't have account ? </a>
                          </span>
                          <br>
                          <button type="button" class="btn btn-warning">Login</button>
                      </form>
                </div>
            </div>
        </div>

     <br>
     <br>

        <section id="section-214">
            <div class="controls row">
                <div class="col" id="column-216">
                    <h5 id="heading-221">
                        Brand Name
                    </h5>
                    <p id="paragraph-222">
                        Short Descriptions:<br>
                        
                    </p>
                    <p id="paragraph-832">
                        Full Address:
                    </p>
                    <p id="paragraph-830">
                        Phone:
                    </p>
                    <p id="paragraph-831">
                        Email:
                    </p>
                </div>
                <div class="col" id="column-217">
                    <h5 id="heading-833">
                        <u>About Section</u>
                    </h5><a href="#" id="link-235">About Us</a> <a href="#" id="link-236">Privacy</a> <a href="#" id="link-915">Term of Use</a> <a href="#" id=
                    "link-237">Payment</a> <a href="#" id="link-238">Cancellation Policy</a> <a href="#" id="link-239">Return and Refund Policy</a> 
                </div>
                <div class="col" id="column-601">
                    <h5 id="heading-834">
                        <u>My Account</u>
                    </h5><a href="#" id="link-602">My Account</a> <a href="#" id="link-603">My Orders</a> <a href="#" id="link-916">Shopping Cart</a> <a href="#" id=
                    "link-604">Wishlist</a> <a href="new.html#post" id="link-605">My Review and Ratings</a> <a href="new.html#trend" id="link-606">FAQ</a> 
                </div>
                <div class="col" id="column-218">
                    <h5 id="heading-219">
                        Follow Us
                    </h5><a target="_blank" href="https://www.instagram.com" id="linkblock-229"><i class="fab fa-instagram" id="icon-230"></i></a> <a target=
                    "_blank" href="https://web.facebook.com" id="linkblock-231"><i class="fab fa-facebook" id="icon-232"></i></a> <a target="_blank" href=
                    "https://twitter.com" id="linkblock-233"><i class="fab fa-twitter" id="icon-234"></i></a>
                    <p id="paragraph-829">
                        Subscribe to get our latest offers and updates.
                    </p>
                    <form id="form-223" name="form-223">
                        <input type="text" placeholder="Enter your email" value="" id="textinput-227"> <a class="btn btn-primary btn" href="#" id="button-228">Subscribe</a>
                        
                    </form>
                </div>
            </div>
        </section>
        

        <?php

include 'footer.php';


?>