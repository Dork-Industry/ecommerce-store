<?php

include 'Main.php';

?>

<div class="container-fluid">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 Offer">
<br>
        <span><strong>LIMITED TIME OFFER </strong> &nbsp;This Offer is Provided on Limited Time</span>
        <a href="" class="btn">Create Now</a>
    </div>
</div>
        </div>
        <nav class="navbar navbar-expand-lg navbar-light" id="linkbar-1">
             <a class="navbar-brand" href="new.html" id="linkblock-2"><img src="img/6421701a8c461_1679912986.png" id="image-11"></a> <button class=
            "navbar-toggler" type="button" data-toggle="collapse" data-target="#-navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label=
            "Toggle navigation"><span class="navbar-toggler-icon"></span></button> 
            <div class="collapse navbar-collapse" id="-navbarSupportedContent">
                <ul class="navbar-nav ml-auto navbar" id="navmenu-3">
                    <li class="nav-item">
                        <a class="nav-link" href="#" id="link-684">Home</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Producut.html" id="link-6">Platinum</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Producut.html" id="link-346">Gold</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Producut.html" id="link-7">Diamond</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Producut.html" id="link-8">Silver</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" id="link-9">Offers</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aboutus.html" id="link-10">About Us</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contactus.html" id="link-474">Contact</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php" id="link-474">Login</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Register.php" id="link-474">Sign up</a> 
                    </li>
                </ul>
            </div>
        </nav>